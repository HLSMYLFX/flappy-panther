function init() {
  var user = sessionStorage.getItem("userId");
  var pwd = sessionStorage.getItem("pwd");
  var score = sessionStorage.getItem("score");
  var signup = document.getElementById("signup");
  var login = document.getElementById("login");
  var logout = document.getElementById("logout");
  var welcome = document.getElementById("welcome");
  var play = document.getElementById("play");
  var db = document.getElementById("db");
  var myaccount = document.getElementById("myaccount");
  var Accountwelcome = document.getElementById("Accountwelcome");
  var lastscore = document.getElementById("lastscore");
  var sharebutton = document.getElementById("sharebutton");
  if(user==null || pwd==null||user=="null" || pwd=="null"){
    play.style.display='none';
    db.style.display='none';
    myaccount.style.display='none';
    logout.style.display='none';
    welcome.style.display='none';
    signup.style.display='block';
    login.style.display='block';
  }
  else{
    play.style.display='block';
    db.style.display='block';
    myaccount.style.display='block';
    logout.style.display='block';
    welcome.style.display='block';
    signup.style.display='none';
    login.style.display='none';
    welcome.innerText = "Welcome " + user+"!";
    if(Accountwelcome !=null && Accountwelcome !="null"){
      Accountwelcome.innerText =  "Welcome " + user+"!";
      if(score!=null && score!="null"){
        lastscore.innerText =  "Your last score is "+score+", would you like to share?";
        sharebutton.style.display = 'block';
      }
    }
  }
}
//logout---------------------------------------------
function logout() {
  sessionStorage.setItem("userId",null);
  sessionStorage.setItem("pwd",null);
  sessionStorage.setItem("score",null);
  location.href="/";
}
//login---------------------------------------------
function login() {
  var name = document.getElementById("name").value;
  var pwd = document.getElementById("pwd").value;
  $.ajax({
    url: "http://localhost:8082/process_login",
    type: "post",
    data: {
      userName: name,
      pwd: pwd
    },
    success: function(res) {
      console.log(res);
      if (res.code == 0) {
        sessionStorage.setItem("userId",name);
        sessionStorage.setItem("pwd",pwd);
        location.reload();
      } else {
        alert(res.message);
      }
    }
  });
}
//sign_up---------------------------------------------
function signup() {
  var Sname = document.getElementById("Sname").value;
  var Spwd = document.getElementById("Spwd").value;
  $.ajax({
    url: "http://localhost:8082/process_register",
    type: "post",
    data: {
      SuserName: Sname,
      Spwd: Spwd
    },
    success: function(res) {
      console.log(res);
      if (res.code == 0) {
        sessionStorage.setItem("userId",Sname);
        sessionStorage.setItem("pwd",Spwd);
        location.reload();
      } else {
        alert(res.message);
      }
    }
  });
}
//Share---------------------------------------------
function share() {
  var myDate = new Date();
  var yourscore =  sessionStorage.getItem("score");
  document.getElementById("sharedate").value =  myDate;
  document.getElementById("sharescore").value = yourscore;
}